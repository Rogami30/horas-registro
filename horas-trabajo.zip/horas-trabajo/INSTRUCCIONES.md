# Registro de Horas — Instrucciones de instalación

## Paso 1: Subir a GitHub Pages

1. Ve a **github.com** e inicia sesión
2. Clic en **"New repository"** (botón verde arriba a la derecha)
3. Ponle de nombre: `horas-trabajo`
4. Márcalo como **Public**
5. Clic en **"Create repository"**
6. En la página del repositorio vacío, haz clic en **"uploading an existing file"**
7. Arrastra TODOS los archivos de esta carpeta (index.html, sw.js, manifest.json y la carpeta icons/)
8. Clic en **"Commit changes"**

## Paso 2: Activar GitHub Pages

1. Ve a **Settings** (pestaña en tu repositorio)
2. En el menú izquierdo, haz clic en **"Pages"**
3. En "Source" selecciona **"Deploy from a branch"**
4. En Branch selecciona **"main"** y carpeta **"/ (root)"**
5. Clic en **"Save"**
6. Espera 2-3 minutos y tu app estará en:
   `https://TU_USUARIO.github.io/horas-trabajo/`

## Paso 3: Instalar en el móvil Android

1. Abre Chrome en tu Android
2. Ve a la URL de tu app (la de arriba)
3. Chrome mostrará un banner "Añadir a pantalla de inicio" — tócalo
4. Si no aparece el banner: toca los **3 puntos** (menú) → "Añadir a pantalla de inicio"
5. Confirma y la app aparecerá como icono en tu móvil

## Paso 4: Activar notificaciones

1. Abre la app desde el icono (importante: no desde Chrome directamente)
2. Ve a la pestaña **Ajustes** (⚙)
3. Activa "Activar recordatorios"
4. Acepta el permiso de notificaciones cuando te lo pida
5. Ajusta los horarios de aviso según te convenga

## Notas

- Los datos se guardan en el móvil (no necesitas internet para usarla)
- Para hacer copia de seguridad usa el botón "Exportar CSV" en Ajustes
- El CSV se puede abrir directamente en Excel
